from flask import Flask, render_template, request
from google import genai

app = Flask(__name__)

client = genai.Client(api_key="AQ.Ab8RN6K2-xh4_MD1a_a3js7ZHeovT7o2gdP78zPCKvE0j2tEIg")

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        user_input = request.form["user_input"]
        try:
            response = client.models.generate_content(
                model="gemini-2.5-flash",
                contents=user_input,
            )
            return render_template(
                "index.html",
                user_input=user_input,
                response=response.text
            )
        except Exception as e:
            return render_template("index.html", error=str(e))

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True, port=5001)


